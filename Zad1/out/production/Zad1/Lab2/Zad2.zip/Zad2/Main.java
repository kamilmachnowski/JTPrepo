package Lab2.Zad2;

public class Main {
    MyAnchor anchor = new MyAnchor();

    anchor.insertAtTheFront(5);
}
